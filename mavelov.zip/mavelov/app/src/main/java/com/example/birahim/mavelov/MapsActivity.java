package com.example.birahim.mavelov;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ZoomControls;


import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;

import com.google.android.gms.maps.model.MarkerOptions;


public class MapsActivity extends FragmentActivity implements OnMapReadyCallback , LocationListener {

    private GoogleMap mMap;
    private LocationManager lm;
    EditText mE;
    Button mB;
    String M1 = "Terreaux Terme";  String M5 = "Subsistances"; String M9 = "Terreaux Chenavard"; String M13 = "Rouville"; String M17 = "Quai Lassagne"; String M21 = "Place Ampere"; String M25 = "Patinoire Charlemagne"; String M29 = "Sala Rue du Plat";
    String M2 = "Opera"; String M6 = "Ampere"; String M10 = "Terreaux Herriot"; String M14 = "Place de la Paix"; String M18 = "Aveyron"; String M22 = "Perrache  Carnot"; String M26 = "Bellecour Antonin Poncet"; String M30 = "Gailleton";
    String M3 = "Place Sathona"; String M7 = "Martiniere"; String M11 = "Place Tolozan"; String M15 = "Pizay"; String M19 = "Bellecour Republique"; String M23 = "Confluence Hotel de Region"; String M27 = "Confluence Les Docks"; String M31 = "";
    String M4 = "Meissonier"; String M8 = "Pecherie"; String M12 = "Croix Rousse Duplat"; String M16 = "Carmelites Burdeau"; String M20 = "Bellecour"; String M24 = "Place de l'Hippodrome"; String M28 = "Confluence Darse";
    private static final int PERMS_CALL_ID = 1234;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);




    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    @Override
    // @SuppressWarnings("MissingPermission")
    protected void onResume() {
        super.onResume();

        checkPermissions();
    }

    private void checkPermissions()
    {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]
                    {
                            Manifest.permission.ACCESS_COARSE_LOCATION,
                            Manifest.permission.ACCESS_FINE_LOCATION
                    },PERMS_CALL_ID );

            return;
        }
        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        if (lm != null && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {

            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 50000, 0, this);
        }
        if (lm != null && lm.isProviderEnabled(LocationManager.PASSIVE_PROVIDER)) {
            lm.requestLocationUpdates(LocationManager.PASSIVE_PROVIDER, 50000, 0, this);
        }
        if (lm != null && lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 50000, 0, this);
        }


    }



    @SuppressWarnings("MissingPermission")
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        final LatLng terme = new LatLng(45.767734686399997,4.83213506219);
        final LatLng opera = new LatLng(45.767506910500003 ,4.83628239969);
        final LatLng placeSathonay = new  LatLng(45.765811382199999 ,4.83689574142);
        final LatLng meissonier = new LatLng(45.767895769500001 ,4.81981665742);
        final LatLng subsistances = new LatLng(45.766088600800003 ,4.83288970828);
        final LatLng ampere = new LatLng(45.769265846300001,4.83007978877);
        final LatLng martiniere = new LatLng(45.768218316599999,4.82762170447);
        final LatLng pecherie = new LatLng(45.765949493900003,4.83110736609);
        final LatLng chenavard = new LatLng(45.766805527700001,4.83293380868);
        LatLng herriot = new LatLng(45.766836846099999, 4.83433332127);
        final LatLng placeTolazan = new LatLng(45.769604422,4.83765826124);
        LatLng duplat = new LatLng(45.772284858500001 ,4.81948885202);
        LatLng rouville = new LatLng(45.769662873599998, 4.82463490878);
        LatLng placeDeLaPaix= new LatLng(45.768023612699999, 4.83174125172);
        LatLng pizay= new LatLng(45.767200417200002,4.83639168536);
        LatLng carmelitesBurdeau = new LatLng(45.7700015741 , 4.829269505320001);
        LatLng quaiLassagne = new LatLng(45.772201469300001, 4.83791179293);
        LatLng aveyron = new LatLng( 45.7743716158,4.83281500876);
        final LatLng bellecour = new LatLng(45.757962515899997,4.83463639281);
        LatLng placeAmpere = new LatLng( 45.758262043, 4.83043945355);
        LatLng perracheCarnot = new LatLng( 45.753043707400003 ,4.82826728262);
        LatLng confluenceHotelVille = new LatLng( 45.750099643299997, 4.82805150136);
        LatLng placeHippodrome = new LatLng(45.740538315199998,4.81917951844);
        LatLng patinoireCharlemagne = new LatLng( 45.745581552200001, 4.82353267324);
        LatLng antoninPoncet = new LatLng(45.742646393500003 , 4.82049353569);
        LatLng lesDocks = new LatLng( 45.756766404700002, 4.83384102171);
        LatLng darse = new LatLng(45.739607502799998,4.83463639281);
        LatLng salaRueDuPlat =new LatLng( 45.758262043, 4.81507396337);
        LatLng gailleton = new LatLng(45.743391975 ,4.81581631156);
        final LatLng sydney = new LatLng( 45.756808487599997, 4.828374380140001);



        final String na =  sydney.toString();


        mMap.moveCamera(CameraUpdateFactory.zoomBy(11));
        mMap.setMyLocationEnabled(true);
        mMap.addMarker(new MarkerOptions()
                .position(terme)
                .title(M1)
                .icon(BitmapDescriptorFactory
                        .fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(opera).title(M2).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(placeSathonay).title(M3).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(meissonier).title(M4).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(subsistances).title(M5).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(ampere).title(M6).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(martiniere).title(M7).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));

        mMap.addMarker(new MarkerOptions().position(pecherie).title(M8).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(chenavard).title(M9).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(herriot).title(M10).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(placeTolazan).title(M11).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(duplat).title(M12).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(rouville).title(M13).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(placeDeLaPaix).title(M14).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(pizay).title(M15).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(carmelitesBurdeau).title(M16).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(quaiLassagne).title(M17).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(aveyron).title(M18).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(bellecour).title(M19).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(placeAmpere).title(M20).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));


        mMap.addMarker(new MarkerOptions().position(perracheCarnot).title(M21).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(confluenceHotelVille).title(M22).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(placeHippodrome).title(M23).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(patinoireCharlemagne).title(M24).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(antoninPoncet).title(M25).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(lesDocks).title(M26).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(darse).title(M27).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(salaRueDuPlat).title(M28).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(gailleton).title(M29).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));
        mMap.addMarker(new MarkerOptions().position(sydney).title(M30).icon(BitmapDescriptorFactory.fromResource(R.mipmap.locations)));




        mE = (EditText)(findViewById(R.id.editText1));
        mB = (Button)(findViewById(R.id.button1));

        mB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String search  = mE.getText().toString();




                int duration = Toast.LENGTH_SHORT;
                Context context = getApplicationContext();

                if (search.equals("opera"))
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(opera)
                            .zoom(17).build();
                    //Zoom in and animate the camera.
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else if(search.equals("Terreaux Terme"))
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(terme)
                            .zoom(17).build();
                    //Zoom in and animate the camera.
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else if(search.equals("Opera"))
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(opera)
                            .zoom(17).build();
                    //Zoom in and animate the camera.
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else if(search.equals("Place Sathonay"))
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(placeSathonay)
                            .zoom(17).build();
                    //Zoom in and animate the camera.
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else if(search.equals("Meissonier"))
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(meissonier)
                            .zoom(17).build();
                    //Zoom in and animate the camera.
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else if(search.equals("Subsistances"))
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(subsistances)
                            .zoom(17).build();
                    //Zoom in and animate the camera.
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else if(search.equals("Ampere"))
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(ampere)
                            .zoom(17).build();
                    //Zoom in and animate the camera.
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else if(search.equals("Martiniere"))
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(martiniere)
                            .zoom(17).build();
                    //Zoom in and animate the camera.
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else if(search.equals("Pecherie"))
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(pecherie)
                            .zoom(17).build();
                    //Zoom in and animate the camera.
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else if(search.equals("Terreaux Chenavard"))
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(chenavard)
                            .zoom(17).build();
                    //Zoom in and animate the camera.
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else if(search.equals("Place Tolozan"))
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(placeTolazan)
                            .zoom(17).build();
                    //Zoom in and animate the camera.
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else if(search.equals("Bellecour"))
                {
                    CameraPosition cameraPosition = new CameraPosition.Builder()
                            .target(bellecour)
                            .zoom(17).build();
                    //Zoom in and animate the camera.
                    mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                }
                else
                {


                    Toast.makeText(getApplicationContext(), "Ooops ! Cette addresse est introuvable ... ", Toast.LENGTH_SHORT).show();

                }





            }
        });



    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == PERMS_CALL_ID)
        {
            checkPermissions();
        }

    }

    @Override
    protected void onPause() {
        super.onPause();

        if(lm!=null)
        {
            lm.removeUpdates(this);
        }
    }

    @Override
    public void onProviderDisabled(String provider) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onLocationChanged(Location location) {
        double latitude =  location.getLatitude();
        double longitude = location.getLongitude();

      //  Toast.makeText(this, "latitude: "+latitude+" // "+"Longitude"+longitude, Toast.LENGTH_LONG).show();

        if(mMap!=null)
        {
            LatLng googleLocation = new LatLng(latitude, longitude);
            mMap.moveCamera(CameraUpdateFactory.newLatLng(googleLocation));
        }
    }
}
