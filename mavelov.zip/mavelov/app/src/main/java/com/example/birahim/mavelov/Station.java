package com.example.birahim.mavelov;

public class Station {

      private int procedure;
      private String description;
       private int longitude;
       private int latitude ;

    public Station() {
    }

    public Station(int procedure, String description, int longitude, int latitude) {
        this.procedure = procedure;
        this.description = description;
        this.longitude = longitude;
        this.latitude = latitude;
    }

    public int getProcedure() {
        return procedure;
    }

    public void setProcedure(int procedure) {
        this.procedure = procedure;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getLongitude() {
        return longitude;
    }

    public void setLongitude(int longitude) {
        this.longitude = longitude;
    }

    public int getLatitude() {
        return latitude;
    }

    public void setLatitude(int latitude) {
        this.latitude = latitude;
    }


}
